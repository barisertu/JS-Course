/* Without Arrow Functions
const sayHello = function(){
  console.log('Hello');
}

const sayHello = () =>{
  console.log('Hello');
}

//One Line Function doesn't need braces
const sayHello = () => console.log('Hello');

//Returning One Line
const sayHello = () => 'Hello';
console.log(sayHello());
*/

//Logging Object 
//const sayHello = () => ({msg: 'Hello'});


//Single Parameter
//const sayHello = name => console.log(`Hello ${name}`)
//Multiple Parameter
const sayHello = (firstName, lastName) => console.log(`Hello ${firstName} ${lastName }`)

sayHello('Baris', 'Ertugrul');