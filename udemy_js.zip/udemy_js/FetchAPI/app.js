document.getElementById('txt').addEventListener('click', getText);
document.getElementById('json').addEventListener('click', getJson);
document.getElementById('api-data').addEventListener('click', getApiData);

function getText(){
  fetch('text.txt').then(function(res){
    console.log(res)
    return (res.text());
  })
  .then(function(data){
    console.log(data);
    document.getElementById('output').innerHTML = data;
  })
  .catch(function(err){
    console.log(err);
  });
}

function getJson(){
  fetch('text.json').then(function(res){
    return (res.json());
  })
  .then(function(data){
    let output = '';
    data.forEach(function(user){
      output += 
      `
      <li>Name: ${user.name}</li>
      <li>Age: ${user.age}</li>
      <hr>
      `;
    })
    document.getElementById('output').innerHTML = output;
  })
  .catch(function(err){
    console.log(err);
  });
}


function getApiData(){
  fetch('https://api.github.com/users').then(function(res){
    return (res.json());
  })
  .then(function(data){
    let output = '';
    data.forEach(function(user){
      output += 
      `
      <li>User Name: ${user.login}</li>
      <hr>
      `;
    })
    document.getElementById('output').innerHTML = output;
  })
  .catch(function(err){
    console.log(err);
  });
}