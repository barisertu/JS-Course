class GitHub{
  constructor(){
    this.client_id = "1314d004464e1b9762bc";
    this.client_secret = "fcaedefc8227d42abea6ab5b86706a41f3de20f8";
  }

  async getUser(user){
    const profileResponse = await fetch(`https://api.github.com/users/${user}?client_id=${this.client_id}&client_secret=${this.client_secret}`);

    const profile =await profileResponse.json();

    return {profile: profile}
  }
}