const posts = [
 {title: 'Post One', body: 'This ist post one'},
 {title: 'Post Two', body: 'This ist post two'}
]


/* Synchronized Way
function createPost(post){
  setTimeout(function(){
    posts.push(post);
  }, 2000)
}

function getPosts(){
  setTimeout(function(){
    let output = '';
    posts.forEach(function(post){
      output += `<li>Title: ${post.title} ${post.body}  </li>`;
    });
    document.body.innerHTML = output;
  }, 1000);
}

createPost({title: 'Post Three', body: 'This is post two'});
getPosts();
*/

/*Asynchronized Way with Callbacks
function createPost(post, callback){
  setTimeout(function(){
    posts.push(post);
    callback();
  }, 2000)
  
}

function getPosts(){
  setTimeout(function(){
    let output = '';
    posts.forEach(function(post){
      output += `<li>Title: ${post.title} ${post.body}</li>`;
    });
    document.body.innerHTML = output;
  }, 1000);
}

createPost( {title: 'Post Three', body: 'This ist post three'}, getPosts);
*/

//Asynchronized Way with Promise
function createPost(post){
  return new Promise(function(resolve, reject){
    setTimeout(function(){
      posts.push(post);
      const error = true;

      if(!error){
        resolve()
      }else{
        reject('Error something went wrong.');
      }
      
    }, 2000)
  });

}

function getPosts(){
  setTimeout(function(){
    let output = '';
    posts.forEach(function(post){
      output += `<li>Title: ${post.title} ${post.body}</li>`;
    });
    document.body.innerHTML = output;
  }, 1000);
}

createPost( {title: 'Post Three', body: 'This ist post three'}).then(getPosts).catch(function(err){
  console.log(err);
});
